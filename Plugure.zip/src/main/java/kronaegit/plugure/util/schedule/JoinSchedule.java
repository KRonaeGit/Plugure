package kronaegit.plugure.util.schedule;

import org.bukkit.event.player.PlayerJoinEvent;

public interface JoinSchedule {
    void schedule(PlayerJoinEvent event);
}
