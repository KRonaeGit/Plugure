package before;

import net.kyori.adventure.audience.Audience;
import org.bukkit.Server;

import java.util.Objects;

public class Messenger {
    private final String pc;
    private final String pp;
    private final Server server;
    public Messenger(Server server, String console, String player) {
        this.pc = console;
        this.pp = player;
        this.server = server;
    }
    public String getConsolePrefix() {
        return pc;
    }
    public String getPlayerPrefix() {
        return pc;
    }

    @Override
    public String toString() {
        return "Messenger{" + "console=\"" + pc + '"' + ", player=\"" + pp + '"' + '}';
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Messenger messenger = (Messenger) o;
        return Objects.equals(pc, messenger.pc) && Objects.equals(pp, messenger.pp) && Objects.equals(server, messenger.server);
    }
    @Override
    public int hashCode() {
        return Objects.hash(pc, pp, server);
    }

    public Messenger log(String pattern, Options options) {
        return say(server.getConsoleSender(), pattern, true, options);
    }
    public Messenger log(String pattern) {
        return say(server.getConsoleSender(), pattern, true, Options.empty());
    }
    public Messenger say(Audience audience, String pattern, Options options) {
        audience.sendMessage(Formatter.format(pp + pattern, false, options));
        return messenger;
    }
    public Messenger say(Audience audience, String pattern, boolean detailed, Options options) {
        audience.sendMessage(Formatter.format(pp + pattern, detailed, options));
        return messenger;
    }

    private static Messenger messenger;
    public static Messenger init(Messenger messenger) {
        if(messenger == null)
            return null;
        return Messenger.messenger = messenger;
    }
    public static Messenger get() {
        if (Messenger.messenger == null)
            throw new RuntimeException("SurvivalKit plugin: kronaegit.mcp.survivalkit.message.Messenger: Messenger Messenger.get(): Please init(Messenger Messenger.init(Messenger)) before using this method. Because there is no Messenger instance to get. You can try to init at plugin enable.");
        return Messenger.messenger;
    }
}
