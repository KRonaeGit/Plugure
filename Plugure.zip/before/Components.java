package before;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.TranslatableComponent;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.ComponentSerializer;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.util.Buildable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.jetbrains.annotations.NotNull;

public class Components {
    private Components() { }
    private static MiniMessage mm = null;
    private static MiniMessage init() {
        return mm == null ? MiniMessage.miniMessage() : mm;
    }
    public static @NotNull String stringify(Component component) {
        return init().serialize(component);
    }
    public static @NotNull Component componentify(String source) {
        return init().deserialize(source);
    }

    public static Component asComponent(Object o, boolean detailed) {
        if(o instanceof Component c)
            return c;
        return Components.componentify(Formatter.colored(Formatter.stringify(o, detailed)));
    }
    public static Component autoTranslatable(@NotNull Entity entity) {
        EntityType type = entity.getType();
        TranslatableComponent translatable = Component.translatable(type.translationKey());
        String name = entity.getName();

        boolean translate = type != EntityType.PLAYER && !entity.isCustomNameVisible();
        return translate ? translatable : Component.text(name);
    }
}
