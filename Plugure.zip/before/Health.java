package before;

import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;

import java.util.Objects;

public class Health {
    private Health() {}
    public static double healthOf(Entity entity) {
        if(entity instanceof LivingEntity live)
            return live.getHealth();
        return 0.0d;
    }
    public static double maxHealthOf(Entity entity) {
        if(entity instanceof LivingEntity live)
            return Objects.requireNonNull(live.getAttribute(Attribute.GENERIC_MAX_HEALTH)).getValue();
        return 0.0d;
    }
    public static double positive(double value) {
        return Math.max(0, value);
    }
    public static double damaged(double health, double damage) {
        return positive(health - damage);
    }
    public static float getRatio(double health, double maxHealth) {
        if(health == 0)
            return 0.0f;
        return (float) (health / maxHealth);
    }
    public static float getRatio(Entity entity) {
        double health = healthOf(entity);
        if(health == 0)
            return 0.0f;
        return (float) (health / maxHealthOf(entity));
    }
}
