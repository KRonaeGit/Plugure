package before;

import org.bukkit.entity.Entity;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Options extends ArrayList<Option<?>> {
    private Options(List<Option<?>> options) {
        super(options);
    }

    public static Options byid(String name, UUID uuid) {
        return Options.by("name", name).put("uuid", uuid);
    }

    public Options put(@NotNull Options options) {
        addAll(options);
        return this;
    }
    public Options put(@NotNull Option<?> option) {
        return put(Options.by(option));
    }
    public Options put(String key, Object value) {
        return put(Option.by(key, value));
    }

    @Contract(" -> new")
    public static @NotNull Options empty() {
        return by(List.of());
    }
    @Contract("_ -> new")
    public static @NotNull Options by(Option<?>... options) {
        return by(List.of(options));
    }
    public static Options by(String key, Object value) {
        return Options.by(Option.by(key, value));
    }
    @Contract(value = "_ -> new", pure = true)
    public static @NotNull Options by(List<Option<?>> options) {
        return new Options(options);
    }
    @Contract("_, _ -> new")
    public static @NotNull Options byEntity(String key, Entity entity) {
        return Options.by(key, entity)
                .put(key + "-name", entity.getName())
                .put(key + "-type", entity.getType())
                .put(key + "-uuid", entity.getUniqueId());
    }
}
