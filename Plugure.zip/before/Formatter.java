package before;

import kronaegit.mcp.survivalkit.SurvivalKit;
import kronaegit.mcp.survivalkit.message.compile.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.Style;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * format : compile inside % symbol
 * compile : compile the code like: 'x:0' to floor x to a int
 */
public class Formatter {
    private Formatter() { }

    public static List<CompilePattern> patterns = new ArrayList<>();
    static {
        patterns.add(new NumberPattern());
        patterns.add(new FloorPattern());
        patterns.add(new FunctionPattern());
        patterns.add(new StringPattern());
        patterns.add(new JSONPattern());
    }
    public static Object compile(String source, Options options) {
        source = source.trim();
        for (Option<?> option : options)
            if (source.equals(option.key))
                return option.val;

        Object result;
        for (CompilePattern pattern : patterns)
            if ((result = pattern.parse(source, options)) != null)
                return result;

        return "$" + source + "$";
    }
    public static String compileText(String source, boolean detailed, Options options) {
        return stringify(compile(source, options), detailed);
    }

    private static final Pattern OPTION_PATTERN = Pattern.compile("%([^%]+)%");
    public static @NotNull String formatText(String pattern, boolean detailed, Options options) {
        pattern = colored(pattern);

        StringBuilder builder = new StringBuilder();
        Matcher matcher = OPTION_PATTERN.matcher(pattern);

        while (matcher.find()) {
            String compiled = compileText(matcher.group(1), detailed, options);
            matcher.appendReplacement(builder, Matcher.quoteReplacement(compiled));
        }
        matcher.appendTail(builder);

        return builder.toString().replace("%%", "%");
    }

    public static @NotNull String colored(@NotNull String pattern) {
        return pattern.replace("§", "&")
                .replace("&0", "<black>")
                .replace("&1", "<dark_blue>")
                .replace("&2", "<dark_green>")
                .replace("&3", "<dark_aqua>")
                .replace("&4", "<dark_red>")
                .replace("&5", "<dark_purple>")
                .replace("&6", "<gold>")
                .replace("&7", "<gray>")
                .replace("&8", "<dark_gray>")
                .replace("&9", "<blue>")
                .replace("&a", "<green>")
                .replace("&b", "<aqua>")
                .replace("&c", "<red>")
                .replace("&d", "<light_purple>")
                .replace("&e", "<yellow>")
                .replace("&f", "<white>")
                .replace("&k", "<obfuscated>")
                .replace("&l", "<bold>")
                .replace("&m", "<strikethrough>")
                .replace("&n", "<underlined>")
                .replace("&o", "<italic>")
                .replace("&r", "<reset>");
    }

    private static Style getLastStyle(@NotNull Component component) {
        return component.children().isEmpty() ? component.style() : getLastStyle(component.children().get(component.children().size() - 1));
    }
    public static @NotNull Component format(@NotNull String pattern, boolean detailed, Options options) {
        Component result = Component.empty();

        String buffer = "";
        boolean open = false;
        for (int i = 0; i < pattern.length(); i++) {
            String c = pattern.substring(i, i + 1);
            if (c.equals("%")) {
                if (open)
                    result = result.append(Components.asComponent(compile(buffer, options), detailed).style(getLastStyle(result)));
                else
                    result = result.append(Components.componentify(colored(buffer)).style(getLastStyle(result)));
                buffer = "";
                open = !open;
                continue;
            }
            buffer += c;
        }
        if (open)
            throw new IllegalArgumentException("% is still open til it ended.");

        return result.append(Components.componentify(colored(buffer)).style(getLastStyle(result)));
    }
    public static String stringify(Object o, boolean detailed) {

    }

    public static Number numberify(Object o) {
        if (!(o instanceof Number num))
            throw new IllegalArgumentException("Not a number: " + o);
        return num;
    }
    public static Double doublify(Object o) {
        if (!(numberify(o) instanceof Double d))
            throw new IllegalArgumentException("Not a double: " + o);
        return d;
    }
}
