package before.compile;

import before.Formatter;
import before.Option;
import before.Options;
import kronaegit.mcp.survivalkit.message.compile.function.CeilFunction;
import kronaegit.mcp.survivalkit.message.compile.function.FloorFunction;
import kronaegit.mcp.survivalkit.message.compile.function.Function;
import kronaegit.mcp.survivalkit.message.compile.function.RoundFunction;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FloorPattern implements CompilePattern {
    private static Pattern pattern = Pattern.compile("^(.+):([^:]+)$");
    public Object parse(@NotNull String source, Options options) {
        Matcher matcher = pattern.matcher(source);
        if(!matcher.matches())
            return null;

        Object x = Formatter.compile(matcher.group(1), options);
        Object y = Formatter.compile(matcher.group(2), options);

        return new FloorFunction().run(List.of(x, y));
    }
}
