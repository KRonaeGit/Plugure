package before.compile.function;

import before.Formatter;

import java.util.List;

public interface MathFunction extends Function {
    default Number run(List<Object> parameters) {
        switch(parameters.size()) {
            case 1:
                return run(Formatter.numberify(parameters.get(0)));
            case 2:
                return run(Formatter.numberify(parameters.get(0)), Formatter.numberify(parameters.get(1)));
            default:
                return null;
        }

    }
    Number run(Number x, Number y);

    Number run(Number x);
}
