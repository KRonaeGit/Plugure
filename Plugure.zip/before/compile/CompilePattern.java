package before.compile;

import before.Options;
import org.jetbrains.annotations.NotNull;

public interface CompilePattern {
    Object parse(@NotNull String source, Options options);
}
