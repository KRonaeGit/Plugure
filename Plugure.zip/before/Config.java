package before;

import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.Objects;

public class Config {
    private final YamlConfiguration config;
    public Config(YamlConfiguration config) {
        this.config = config;
    }
    public Config() {
        this(new YamlConfiguration());
    }

    public static Config fromDefault(JavaPlugin plugin, String path) {
        if(path == null || path.isEmpty())
            return null;

        File file = new File(plugin.getDataFolder(), path);
        try {
            if(!file.exists()) {
                Messenger.get().log("There isn't a file: " + path + ". Auto generating...");
                plugin.saveResource(path, false);
                Messenger.get().log("Generated: " + path);
            }
        } catch(IllegalArgumentException e) {
            throw new RuntimeException("Cannot load the resource: " + path, e);
        }
        return Config.from(file);
    }

    public String getString(String path) {
        return config.getString(path);
    }
    public Component getMessage(String path, boolean detailed, Options options) {
        return Formatter.format(Objects.requireNonNull(config.getString(path)), detailed, options);
    }
    public String getMessageText(String path, boolean detailed, Options options) {
        return Formatter.formatText(config.getString(path), detailed, options);
    }
    public void sendMessage(Audience audience, String path, boolean detailed, Options options) {
        audience.sendMessage(getMessage(path, detailed, options));
    }

    public static @Nullable Config from(File dataFolder, String name) {
        return from(new File(dataFolder, name));
    }
    private static Config from(File file) {
        if(!file.exists())
            return null;
        return new Config(YamlConfiguration.loadConfiguration(file));
    }

    public Config set(String path, Object value) {
        config.set(path, value);
        return this;
    }

    @Override
    public String toString() {
        return "Yaml{" + config.toString() + '}';
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Config config = (Config) o;
        return Objects.equals(this.config, config.config);
    }
    @Override
    public int hashCode() {
        return Objects.hash(config);
    }

    public double getDouble(String path) {
        return config.getDouble(path);
    }

}
