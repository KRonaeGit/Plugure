package before;

import org.bukkit.entity.Entity;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public class Option<T> {
    public final String key;
    public final T val;
    private Option(String key, T value) {
        this.key = key;
        this.val = value;
    }
    @Contract(value = "_, _ -> new", pure = true)
    public static <T> @NotNull Option<T> by(String key, T value) {
        return new Option<>(key, value);
    }
    @Contract(pure = true)
    public static @Nullable Object get(@NotNull String key, @NotNull Option<?> @NotNull ... options) {
        for (Option<?> option : options)
            if(option.key.equals(key))
                return option.val;
        return null;
    }
    @Override
    public String toString() {
        return "Option{" + key + ':' + val + '}';
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Option<?> option = (Option<?>) o;
        return Objects.equals(key, option.key) && Objects.equals(val, option.val);
    }
    @Override
    public int hashCode() {
        return Objects.hash(key, val);
    }
}
